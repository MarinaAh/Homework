public class Main {
     public static void main  (String[] args) {
          //Задание 1
          byte myByte = 4;
          char myLetter = 'G';
          int myNum = 89;
          short myshort = 56;
          float myFloatNum = 4.7333436f;
          double mydouble = 4.355453532;
          Long myLong = 12121l;
          System.out.println("myByte\n"+"myLetter\n"+"myNum\n"+"myshort\n"+ "myFloatNum\n"+ "mydouble\n"+ "mydouble\n" +"myLong\n");
     }
}


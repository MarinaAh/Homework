public class Main {
    public static void main(String[] args){
                byte b = 127;// При значении b=128 выдает ошибку
                //byte  b = b + 1; почемуто b подчеркнуто красным
        int a=10;
        int d =5;
        int c=a*d;
        System.out.println(c);
        //тип целого числа
         double k=10.5;
        double f= 4.5;
        double h=k*f;
        System.out.println(h);
        //тип дробного числа
         char  A= 'A';
         char B='A'+'1';
        System.out.println(A);
        System.out.println(B);
    }
}
public class Main {
    public static void main(String[] args) {

        //Задание 2

        int myInt = 345;
        int x1 = myInt / 100;
        int x2 = (myInt / 10) % 10;
        int x3 = myInt%10;
        System.out.println(x1+", "+x2+", "+x3);
      //Задание 3

        int main = 987;
        int y1 = main / 100;
        int y2 = (main / 10) % 10;
        int y3 = main%10;
        System.out.print(y1+", "+y2+", "+y3);
    }
}